---
tipo: negocio
estado: activo
aliases: [Reputation Bundle, Review Automation]
actualizado: 2026-09-25
---
# Reputation Bundle

## Resumen
Gestión de reseñas de Google para negocios de servicios del hogar en Florida (tree service, roofing, plomería, HVAC, contratistas generales). Modelo concierge: Bryan gestiona manualmente el perfil de Google del cliente. Meta: ingresos este mes, automatización después.

## Modelo
- Precio Founding Partner: $149/mes fijo para los primeros 10 negocios; luego $249/mes.
- Incluye respuestas a reseñas con Claude, solicitudes de reseña manuales y reporte mensual.

## Arquitectura
- Landing trilingüe (EN/ES/FR) en bundle.theorangebusiness.com (nginx, un solo archivo estático).
- Diseño: fondo charcoal, tarjetas color crema tipo ticket, naranja/ámbar de marca. Scoutie Sans (títulos), Public Sans (cuerpo), IBM Plex Mono (etiquetas).
- Copy centrado en un momento concreto: el cliente que prometió una reseña y nunca la dejó.
- Leads: Apollo.io y Outscraper (mejor para teléfono, rating y cantidad de reseñas).
- Proyecto en el VPS en `/opt/reputation-bundle/`.

## Pendientes
- [ ] Resolver cómo recibir USD sin LLC en EE.UU. (PayPal Business o Wise Business).
- [ ] Contactar a los 13 prospectos reales de Kissimmee del tracker.

## Decisiones
- 2026-08-29 - Pivote de Canadá bilingüe ($199 CAD) a Florida. Por qué: EE.UU. paga más fácil por servicios digitales y Bryan se muda allá.
- 2026-08-29 - Concierge manual en vez de construir la plataforma de 8 fases. Por qué: ingresos inmediatos.
- Mobile Text Alerts solo como canal secundario. Por qué: está hecho para suscriptores opt-in, no para outreach en frío.
